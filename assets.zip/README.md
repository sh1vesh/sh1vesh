<div align="center">

  <img src="./assets/cover.svg" width="100%" alt="Shivesh — Data Engineering, MERN and Cloud" />

  <br />

  <a href="https://github.com/sh1vesh?tab=followers">
    <img src="https://img.shields.io/badge/FOLLOW-111111?style=flat-square&logo=github&logoColor=F5F0E6" alt="Follow Shivesh on GitHub" />
  </a>
  <a href="https://www.linkedin.com/in/shen83/">
    <img src="https://img.shields.io/badge/LINKEDIN-315CFF?style=flat-square&logo=linkedin&logoColor=white" alt="Connect with Shivesh on LinkedIn" />
  </a>
  <a href="https://x.com/bl3_eed">
    <img src="https://img.shields.io/badge/@BL3__EED-111111?style=flat-square&logo=x&logoColor=white" alt="Follow Shivesh on X" />
  </a>
  <a href="mailto:shivesh85674@gmail.com">
    <img src="https://img.shields.io/badge/EMAIL-FF5A1F?style=flat-square&logo=gmail&logoColor=white" alt="Email Shivesh" />
  </a>
  <img src="https://komarev.com/ghpvc/?username=sh1vesh&style=flat-square&label=READERS&color=111111" alt="Profile views" />

</div>

<br />

<div align="center">
  <img src="./assets/field-notes.svg" width="100%" alt="Shivesh's field notes, focus areas and technology stack" />
</div>

<br />

<div align="center">
  <img src="./assets/work-index.svg" width="100%" alt="Selected experiments by Shivesh" />
</div>

<div align="center">

  <a href="https://github.com/sh1vesh/X-Clone-Live-time-single-tweets-">
    <img src="https://img.shields.io/badge/01_TWEETFLICK_API-EXPLORE-111111?style=for-the-badge&labelColor=FF5A1F&logo=x&logoColor=white" alt="Explore TweetFlick API" />
  </a>

  <a href="https://github.com/sh1vesh/myntra-clone">
    <img src="https://img.shields.io/badge/02_MYNTRA_CLONE-EARLY_BUILD-111111?style=for-the-badge&labelColor=315CFF&logo=react&logoColor=white" alt="Explore Myntra Clone" />
  </a>

</div>

<br />

<div align="center">
  <img
    src="https://github-profile-summary-cards.vercel.app/api/cards/profile-details?username=sh1vesh&theme=transparent"
    width="98%"
    alt="Shivesh's live GitHub profile summary"
  />
</div>

<br />

<div align="center">
  <img
    src="https://github-readme-activity-graph.vercel.app/graph?username=sh1vesh&bg_color=F5F0E6&color=111111&line=FF5A1F&point=315CFF&area=true&area_color=FFB38F&hide_border=true&custom_title=BUILD%20LOG"
    width="98%"
    alt="Shivesh's live contribution graph"
  />
</div>

<br />

<div align="center">
  <img src="./assets/closing-note.svg" width="100%" alt="Open to data engineering collaborations" />
</div>

<div align="center">

  <a href="mailto:shivesh85674@gmail.com">
    <img src="https://img.shields.io/badge/START_A_CONVERSATION-FF5A1F?style=for-the-badge&logo=gmail&logoColor=white" alt="Start a conversation" />
  </a>

  <a href="https://github.com/sh1vesh?tab=repositories">
    <img src="https://img.shields.io/badge/OPEN_THE_ARCHIVE-111111?style=for-the-badge&logo=github&logoColor=F5F0E6" alt="Explore Shivesh's repositories" />
  </a>

</div>

<br />

<div align="center">
  <sub>Learning in public · Building one system at a time · India</sub>
</div>
